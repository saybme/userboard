<?php return [
    'plugin' => [
        'name' => 'UB',
        'description' => ''
    ]
];